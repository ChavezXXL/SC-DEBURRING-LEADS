
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-email.ts
import { Resend } from "resend";
var resend = new Resend(process.env.RESEND_API_KEY);
var send_email_default = async (req, _context) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const { to, subject, body, fromName } = await req.json();
    if (!to || !subject || !body) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: to, subject, body" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
    const result = await resend.emails.send({
      from: `${fromName || "Anthony - SC Deburring"} <outreach@${process.env.RESEND_DOMAIN || "scprecisiondeburring.com"}>`,
      to: [to],
      subject,
      text: body
    });
    if (result.error) {
      return new Response(
        JSON.stringify({ success: false, error: result.error.message }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    return new Response(
      JSON.stringify({
        success: true,
        emailId: result.data?.id,
        sentAt: (/* @__PURE__ */ new Date()).toISOString()
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ success: false, error: err?.message || "Internal error" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
};
export {
  send_email_default as default
};
