
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auto-outreach.ts
import { Resend } from "resend";
import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { GoogleGenAI } from "@google/genai";
function getDb() {
  if (getApps().length === 0) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || "{}");
    initializeApp({
      credential: cert(serviceAccount),
      projectId: "sc-deburring-leads"
    });
  }
  return getFirestore();
}
function getAi() {
  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
}
var ANGLES = [
  "overflow_capacity",
  "quality_pain",
  "speed",
  "local_convenience",
  "cost_reduction",
  "specialty_expertise"
];
async function generateEmail(ai, lead) {
  const contact = lead.pm || lead.who || "";
  const firstName = contact.split(" ")[0] || "there";
  const angle = ANGLES[Math.floor(Math.random() * ANGLES.length)];
  const prompt = `You are Anthony, owner of SC Precision Deburring \u2014 a 35-year family-owned aerospace deburring shop in Pacoima, CA. Write a cold email to a potential customer.

RULES:
- Write like a real person. Casual but professional.
- 3-5 sentences MAX. Short paragraphs.
- NEVER use: "I hope this finds you well", "I wanted to reach out", "I'm reaching out", "allow me to introduce", "please don't hesitate", "synergy", "leverage", "solutions"
- NEVER use bullet points or lists
- NEVER start with "Dear" \u2014 use "Hey ${firstName}," or "${firstName},"
- Subject line: lowercase, 2-6 words, sounds like a quick question
- End with: Anthony\\nSC Precision Deburring\\n(818) 890-1515
- Reference something specific about their company

EXAMPLES OF GOOD EMAILS:

Subject: deburring overflow?

Hey Jake,

Saw you guys do a lot of aerospace sheet metal \u2014 deburring in-house or farming out? We're a 35-year shop in Pacoima, microscope-inspected, no minimums. Just turned 500 brackets for a shop in Chatsworth in 3 days.

Happy to run a test batch.

Anthony
SC Deburring LLC
(818) 389-4234
scprecisiondeburring.com
12734 Branford St #17, Arleta CA 91331

---

Subject: quick question about your parts

Mike,

Noticed your shop does a lot of CNC work for aerospace \u2014 do you handle deburring internally? We're right in the Valley and we've been at it for 35 years. Fast turnaround, microscope-inspected.

Would a test run make sense?

Anthony
SC Deburring LLC
(818) 389-4234
scprecisiondeburring.com
12734 Branford St #17, Arleta CA 91331

---

NOW WRITE A FRESH EMAIL (don't copy examples):

Company: ${lead.co}
Contact: ${firstName}
Title: ${lead.role || lead.pm_title || ""}
City: ${lead.city || "unknown"}, CA
Makes: ${lead.parts || "precision components"}
Angle: ${lead.pitch || "aerospace deburring"}
Approach: ${angle.replace("_", " ")}

Return ONLY:
Subject: [subject]

[body]`;
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: { maxOutputTokens: 350 }
  });
  const text = (response.text || "").replace(/\[cite:\s*[\d,\s#]+\]/gi, "").trim();
  const subjectMatch = text.match(/^Subject:\s*(.+)/m);
  const subject = subjectMatch ? subjectMatch[1].trim() : `quick question for ${lead.co}`;
  const body = subjectMatch ? text.replace(/^Subject:\s*.+\n*/m, "").trim() : text;
  return { subject, body };
}
var auto_outreach_default = async (_req, _context) => {
  const db = getDb();
  const resend = new Resend(process.env.RESEND_API_KEY);
  const ai = getAi();
  const settingsSnap = await db.doc("settings/auto-outreach").get();
  const settings = settingsSnap.data() || { enabled: false, mode: "all_new", dailyLimit: 15 };
  if (!settings.enabled) {
    return new Response(JSON.stringify({ message: "Auto-outreach is disabled" }), { status: 200 });
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const logsSnap = await db.collection("outreach-logs").where("sentDate", "==", today).count().get();
  const sentToday = logsSnap.data().count;
  const remaining = Math.max(0, (settings.dailyLimit || 15) - sentToday);
  if (remaining === 0) {
    return new Response(JSON.stringify({ message: "Daily limit reached", sentToday }), { status: 200 });
  }
  let leadsQuery = db.collection("leads").where("status", "==", "new");
  if (settings.mode === "tier1") {
    leadsQuery = leadsQuery.where("t", "==", 1);
  } else if (settings.mode === "tagged") {
    leadsQuery = leadsQuery.where("queued_for_outreach", "==", true);
  }
  const leadsSnap = await leadsQuery.limit(remaining).get();
  if (leadsSnap.empty) {
    return new Response(JSON.stringify({ message: "No eligible leads", sentToday }), { status: 200 });
  }
  const results = [];
  for (const leadDoc of leadsSnap.docs) {
    const lead = { id: leadDoc.id, ...leadDoc.data() };
    if (!lead.em) continue;
    try {
      const { subject, body } = await generateEmail(ai, lead);
      const sendResult = await resend.emails.send({
        from: `Anthony - SC Deburring <outreach@${process.env.RESEND_DOMAIN || "scprecisiondeburring.com"}>`,
        to: [lead.em],
        subject,
        text: body
      });
      if (sendResult.error) {
        results.push({ leadId: lead.id, company: lead.co, error: sendResult.error.message });
        continue;
      }
      await db.collection("outreach-logs").add({
        leadId: lead.id,
        company: lead.co,
        contact: lead.pm || lead.who,
        email: lead.em,
        subject,
        body,
        sentAt: (/* @__PURE__ */ new Date()).toISOString(),
        sentDate: today,
        status: "sent",
        emailId: sendResult.data?.id
      });
      await db.doc(`leads/${lead.id}`).update({
        status: "emailed",
        queued_for_outreach: false
      });
      results.push({ leadId: lead.id, company: lead.co, status: "sent" });
      await new Promise((r) => setTimeout(r, 2e3));
    } catch (err) {
      results.push({ leadId: lead.id, company: lead.co, error: err?.message });
    }
  }
  return new Response(
    JSON.stringify({
      message: "Auto-outreach complete",
      sentToday: sentToday + results.filter((r) => r.status === "sent").length,
      results
    }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
};
var config = {
  schedule: "0 15 * * *"
};
export {
  config,
  auto_outreach_default as default
};
